echo 'Operace,Bash,Fish,CMD
"Výpis textu","echo ""Ahoj""","echo ""Ahoj""","echo Hello"' > data.csv
